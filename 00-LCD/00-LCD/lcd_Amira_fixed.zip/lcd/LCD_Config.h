/*
 * LCD_Config.h
 *
 *  Created on: Nov 30, 2020
 *      Author: merog
 */

#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define controlport 2
#define dataport 0
#define RS 0
#define RW 1
#define E 2

#endif /* LCD_CONFIG_H_ */
